
# filemind/pages/thread_parser_viewer_plugin.py

import streamlit as st
import os
import json

st.set_page_config(page_title="📜 ThreadParser Plugin – FILEMIND Add-on", layout="wide")
st.title("📜 FILEMIND – ThreadParser Viewer Plugin")
st.caption("Modular plugin to inspect full markdown thread exports and sync with Notion or GitHub.")

# Thread Index Loader
st.markdown("### 🧵 Thread Selector")
index_path = "/mnt/data/thread_index.json"
if os.path.exists(index_path):
    with open(index_path, "r") as f:
        threads = json.load(f)
    options = [t.get("thread_name", f"Thread {i+1}") for i, t in enumerate(threads)]
    selected = st.selectbox("Select a thread to view", options)
    st.success(f"Selected: {selected}")
else:
    st.warning("No thread index available.")

# Thread Markdown Viewer
st.markdown("### 📖 Markdown Thread Export")
md_path = "/mnt/data/thread_FULL_EXPORT_REBUILT.md"
if os.path.exists(md_path):
    with open(md_path, "r") as f:
        content = f.read()
        st.code(content[:3000], language="markdown")
else:
    st.warning("Thread markdown not found.")

# Optional Actions (Stub Triggers)
st.markdown("### 🔧 Plugin Triggers")
col1, col2 = st.columns(2)

with col1:
    if st.button("🧭 Sync to Notion (Simulated)"):
        st.info("Notion sync logic would trigger here → notion_sync_threadparser.py")

with col2:
    if st.button("⬆️ Push to GitHub (Simulated)"):
        st.info("GitHub commit logic would trigger here → push_threadparser_github.py")

# Plugin Confirmations
st.markdown("---")
st.success("✅ ThreadParser plugin successfully integrated into FILEMIND environment.")
