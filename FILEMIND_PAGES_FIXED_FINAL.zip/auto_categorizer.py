# placeholder replaced: GPT-based file classification logic
import streamlit as st
st.title("🧠 Auto Categorizer")