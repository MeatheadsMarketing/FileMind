# thread_parser_viewer_plugin.py — Live Streamlit Applet

import streamlit as st
st.title('Thread Parser Viewer Plugin')