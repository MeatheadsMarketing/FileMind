# directory_visualizer.py — Live Streamlit Applet

import streamlit as st
st.title('Directory Visualizer')