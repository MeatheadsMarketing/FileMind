# file_registry_table.py — Live Streamlit Applet

import streamlit as st
st.title('File Registry Table')