# summary_table_generator.py — Live Streamlit Applet

import streamlit as st
st.title('Summary Table Generator')