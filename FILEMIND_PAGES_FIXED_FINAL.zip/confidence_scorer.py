# confidence_scorer.py — Live Streamlit Applet

import streamlit as st
st.title('Confidence Scorer')