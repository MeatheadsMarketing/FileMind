# placeholder replaced: assign cluster groups (merge, scan, etc.)
import streamlit as st
st.title("🧬 Cluster Sorter")