# placeholder replaced: shortcut detection scanner
import streamlit as st
st.title("🏷️ Shortcut Scanner")