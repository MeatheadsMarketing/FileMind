# manual_tag_editor.py — Live Streamlit Applet

import streamlit as st
st.title('Manual Tag Editor')