# extension_summary_chart.py — Live Streamlit Applet

import streamlit as st
st.title('Extension Summary Chart')